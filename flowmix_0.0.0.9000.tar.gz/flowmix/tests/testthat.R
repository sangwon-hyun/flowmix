library(testthat)
library(flowcy)

test_check("flowmix")
