library(testthat)
library(flowmix)

test_check("flowmix")
