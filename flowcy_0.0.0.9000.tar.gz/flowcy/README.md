License: file LICENSE 

Proprietary 

Do not distribute outside of Widgets Incorporated.
