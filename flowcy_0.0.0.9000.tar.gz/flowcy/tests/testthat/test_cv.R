## context("Test cross validation function and its helper functions")

## ## Test the parallel version of the cross validation
## test_that("Parallel CV works as expected.", {

##   ## Generate data
TT = 30
isim = 1
set.seed(isim)
datobj = generate_data_generic(p=5, TT=TT, fac=0.5, nt=100)
ylist = datobj$ylist
X = datobj$X
gridsize = 12
numclust = 4


##   ## Get range of lambdas
##   la()
  maxres = get_max_lambda(ylist, X, numclust, verbose=TRUE)
  pie_lambdas = seq(from=0, to=maxres$alpha, length=gridsize)
  mean_lambdas = seq(from=0, to=maxres$beta, length=gridsize)

##   ## Run CV
##   library(doSNOW)
##   ## ncoresPerNode <- as.numeric(system("getconf _NPROCESSORS_ONLN", intern=TRUE))
##   ## nodeNames = strsplit(system("scontrol show hostname $SLURM_NODELIST | paste -d, -s", intern=TRUE),
##                        ## ",")[[1]]
##   ## machines = rep(nodeNames, each = ncoresPerNode)
##   ## cl = makePSOCKcluster(machines)


##   ## On a local machine, do this
##   cl <- makeCluster(2)

##   ## cl = makeCluster(machines, "FORK")
##   registerDoSNOW(cl)
##   ## clusterExport(cl, c('data'))

##   ## Load the flowcy library on all nodes.
##   emptylist = lapply(1:length(cl), function(ii)c())
##   snow::clusterApply(cl,
##                      emptylist,
##                      function(a) load_all("~/repos/flowcy/flowcy"))

##   ## Run the parallel CV.
  cl = makePSOCKcluster(1)
  parallel_cv.covarem(ylist = ylist, X = X, numclust = numclust,
                      pie_lambdas = pie_lambdas,
                      mean_lambdas = mean_lambdas,
                      maxdev = 0.5,
                      ## Options for parallelizing
                      gridsize = gridsize,
                      nsplit = 5,
                      numfork = 12,
                      verbose = TRUE,
                      nrep = 10,
                      ## multicore.cv = FALSE,
                      destin = "~",
                      warm_start = FALSE,
                      cl = cl)

##   ## Stop usage of the cluster
##   ## snow::stopCluster(cl)
##   ## parallel::stopCluster(cl)
## })
