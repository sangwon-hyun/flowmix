## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = TRUE,
  cache = FALSE,
  cache.lazy = FALSE
)
options(rmarkdown.html_vignette.check_title = FALSE)

## ----installation, eval = FALSE-----------------------------------------------
#  if (!require("BiocManager", quietly = TRUE))
#      install.packages("BiocManager")
#  BiocManager::install("BiocStyle")

## ----setup, message=FALSE-----------------------------------------------------
library(flowmix)
library(tidyverse)
library(RColorBrewer)

## ----generate-data, echo=TRUE-------------------------------------------------
set.seed(0)
datobj = generate_data_generic(p = 5, TT = 300, fac = .2, nt = 2000, dimdat = 3) #
ylist = datobj$ylist
X = datobj$X

## ----viz-one-cytogram, fig.width=5, fig.height=5------------------------------
y = ylist[[1]][,1:2]
colnames(y) = c("dim1", "dim2")
as_tibble(y) %>%
  ggplot() + geom_point(aes(x=dim1, y = dim2), alpha = .3) +
  coord_fixed()

## ----viz-covariates, fig.width=10, fig.height=3-------------------------------
colnames(X) = c("sinewave", "changepoint", "other1", "other2", "other3")
as_tibble(X) %>%
  add_column(time = 1:nrow(X)) %>% 
  pivot_longer(cols = !time)  %>%
  ggplot(aes(x=time, y=value)) +
  facet_grid(.~name) +
  geom_point()

## ----fit-model----------------------------------------------------------------
numclust = 4
set.seed(0)
res = flowmix(ylist = ylist, X = X, numclust = numclust,
              mean_lambda = 0.001, prob_lambda = 0.001,
              nrep = 1)
print(res)

## ----plot-prob, fig.width=7, fig.height=5-------------------------------------
prob = res$prob
colnames(prob) = paste0("Cluster", 1:numclust)

as_tibble(prob) %>% 
  add_column(time = 1:nrow(prob)) %>% 
  pivot_longer(cols = !time)  %>%
  ggplot(aes(x=time, y=value)) +
  facet_grid(.~name) +
  geom_line() +
  ylab("Estimated cluster probability")

## ----make-gif, animation.hook='ffmpeg', dev='jpeg', interval=0.1, ffmpeg.format="gif", fig.width=10, fig.height=3.3, message = FALSE, warning = FALSE----
## Make all 2d plots
ylim = c(-3,8)
xlim = c(-5,8)
for(tt in seq(from=1, to = 300, by = 30)){
  plist = lapply(list(c(1,2), c(2,3), c(3,1)), function(dims){

    ## Take the model estimates for dimensions in \code{dims}
    mn = res$mn[tt,dims,]
    sigma = res$sigma[,dims,dims]
    prob = res$prob[tt,]

    ## Plot them in a figure
    y = ylist[[tt]][,dims] 
    varnames = paste0("dim", dims)
    varname1 = varnames[1]
    varname2 = varnames[2]
    colnames(y) = varnames
    y = y %>% as_tibble()
    p = ggplot(y, aes(x = !!sym(varname1), y = !!sym(varname2))) +
      geom_point(alpha = 0.2) +
      ylim(ylim) +
      xlim(xlim)

    ## Add model
    p1 = add_model_2d(p, mn, sigma, prob)
    return(p1)
  })
  
  gridExtra::grid.arrange(plist[[1]], plist[[2]], plist[[3]], nrow = 1,
                          top = paste0("t = ", tt, " out of ", res$TT))
}

## ----cv, eval = TRUE----------------------------------------------------------
## Define the locations to save the CV results.
destin = "." 

## Define the CV folds (as every fifth, nfold-sized, block of indices)
folds = make_cv_folds(ylist, nfold = 5, blocksize = 20) 

## This saves to a file `maxres.Rdata` under the |destin| directory.
maxres = get_max_lambda(destin,
                        "maxres.Rdata",
                        ylist = ylist,
                        countslist = NULL,
                        X = X,
                        numclust = 4,
                        maxdev = 0.5,
                        max_mean_lambda = 40,
                        max_prob_lambda = 2)

cv_gridsize = 5
prob_lambdas =  logspace(min = 0.0001, max = maxres$alpha, length = cv_gridsize)
mean_lambdas = logspace(min = 0.0001, max = maxres$beta, length = cv_gridsize)

## ----remove-maxres-file, eval = TRUE, echo = FALSE----------------------------
file.remove(file = file.path("maxres.Rdata"))

## ----cv-folds-----------------------------------------------------------------
## Define the CV folds (as every fifth, nfold-sized, block of indices)
folds = make_cv_folds(ylist, nfold = 5, blocksize = 20) 

## ----cv-main, eval = FALSE----------------------------------------------------
#  cvres = cv.flowmix(ylist = ylist,
#                     countslist = NULL,
#                     X = X,
#                     maxdev = 0.5,
#                     numclust = 4,
#                     prob_lambdas = prob_lambdas,
#                     mean_lambdas = mean_lambdas,
#                     nrep = 10,
#                     folds = folds,
#                     destin = destin,
#                     mc.cores = 8)

## ----cv-summary, eval=FALSE---------------------------------------------------
#  cvres = cv_summary(destin = destin,
#                     cv_gridsize = 5,
#                     nrep = 10,
#                     nfold = 5,
#                     save = TRUE,
#                     filename = "summary.RDS")

## ----cv-print, eval=FALSE-----------------------------------------------------
#  print(cvres$bestres)

## ----real-data----------------------------------------------------------------
## Load data
## datobj = readRDS(file = "~/repos/flowmix/paper-data/MGL1704-hourly-paper.RDS")
datobj = readRDS(file = "../inst/extdata/MGL1704-hourly-paper.RDS") ## change to readRDS(system.file("extdata", "MGL1704-hourly-paper.RDS"))
datobj %>% list2env(envir = .GlobalEnv) %>% invisible()

## Estimate model
set.seed(1)
res = flowmix(ylist, X, numclust = 10,
              countslist = countslist,
              mean_lambda = 0.001,
              prob_lambda = 0.001,
              maxdev = 0.5,
              nrep = 1,
              verbose = FALSE)

## ----real-print---------------------------------------------------------------
print(res)

## ----real-prob-plot, fig.width = 10, fig.height = 6---------------------------
numclust = 10
prob = res$prob
colnames(prob) = paste0("Cluster ", 1:numclust)
prob_long = as_tibble(prob) %>% 
  add_column(time = 1:nrow(prob)) %>% 
  pivot_longer(cols = !time) 
prob_long$name = factor(prob_long$name, paste0("Cluster ", 1:numclust))

prob_long %>%
  ggplot(aes(x = time, y = value)) +
  facet_wrap(~name, ncol = 5) +
  geom_line() +
  ylab("Estimated cluster probability")

## ----real-data-plot, fig.width = 10, fig.height = 3.3, message=FALSE, warning=FALSE----
dimnames = c("diam", "red", "orange")
## for(tt in seq(from=1, to = 296, by = 10)){
for(tt in c(50,100,150,200)){
  plist = lapply(list(c(1,2), c(2,3), c(3,1)), function(dims){

    ## Take the model estimates for dimensions in \code{dims}
    mn = res$mn[tt,dims,]
    sigma = res$sigma[,dims,dims]
    prob = res$prob[tt,]

    ## Plot them in 2d 
    y = ylist[[tt]][,dims] 
    varnames = dimnames[dims] ##paste0("dim", dims)
    varname1 = varnames[1]
    varname2 = varnames[2]
    colnames(y) = varnames
    y = y %>% as_tibble()
    p = ggplot(y, aes(x = !!sym(varname1), y = !!sym(varname2))) +
      geom_tile(alpha = 0.2) +
      ylim(c(0,8)) +  xlim(c(0,8))

    ## Add model
    p = add_model_2d(p, mn, sigma, prob)
    return(p)
  })
  gridExtra::grid.arrange(plist[[1]], plist[[2]], plist[[3]], nrow = 1,
                          top = paste0("t = ", tt, " out of ", res$TT))
}

## ----bin-data, fig.width = 5--------------------------------------------------
## Generate synthetic particle-level (non-binned) data
library(flowmix)
set.seed(0)
datobj = generate_data_generic(p = 5, TT = 100, fac = .2, nt = 2000, dimdat = 3)
ylist = datobj$ylist
X = datobj$X
y = ylist %>% .[[1]] %>% as_tibble()
colnames(y) = c("dim1", "dim2", "dim3")

## Plot data before binning
p = ggplot(y) +
  geom_point(aes(x=dim1, y=dim2), alpha = .1, size = rel(1)) +
  coord_fixed()
plot(p)

## ----do-the-binning-----------------------------------------------------------
## Bin this data
grid = make_grid(ylist, gridsize = 30)
obj = bin_many_cytograms(ylist, grid, mc.cores = 4, verbose=FALSE)  
ylist = obj$ybin_list
countslist = obj$counts_list

ylist[[1]] %>% head(15) %>% round(3) %>% print()
countslist[[1]] %>% head(15) %>% print()

## ----bin-plot, fig.width = 5--------------------------------------------------
## Just look at one time point
tt = 10
dims = c(1,2)
y = ylist[[tt]]##[,dims] 
counts = countslist[[tt]]

## Collapse the binned 3d data to 2d
y = flowmix::collapse_3d_to_2d(y, counts, dims = 1:2) %>% as_tibble()
y %>% head(15) %>% round(3) %>% print()

## Plot it
varname1 = colnames(y)[1]
varname2 = colnames(y)[2]
colours = c("white", "blue")
p = ggplot(y) +
  geom_tile(aes(x = !!sym(varname1), y = !!sym(varname2), fill = counts)) +
  theme_grey() +
  scale_fill_gradientn(colours = colours, guide="colorbar") +
  theme(legend.position = "none") +
  coord_fixed() +
  ggtitle(paste0(tt, " out of ", 100))
plot(p)

## ----bin-model----------------------------------------------------------------
## Run the algorithm on binned data
numclust = 4
res = flowmix(ylist = ylist,
              X = X,
              countslist = countslist,
              numclust = numclust,
              mean_lambda = 0.001,
              prob_lambda = 0.001,
              verbose = FALSE,
              maxdev = 0.5)
print(res)

## ----bin-model-plot, fig.width = 5--------------------------------------------
## Add model
mn = res$mn[tt,dims,]
sigma = res$sigma[,dims, dims]
prob = res$prob[tt,]
p = add_model_2d(p, mn, sigma, prob)
plot(p)

## ----one-job, eval=FALSE------------------------------------------------------
#  ## Example of one CV job for one pair of regularization parameters (and CV folds
#  ## and EM replicates)
#  ialpha = 1
#  ibeta = 1
#  ifold = 1
#  irep = 1
#  destin = "~/Desktop"## Change to your target destination.
#  one_job(ialpha = ialpha,
#          ibeta = ibeta,
#          ifold = ifold,
#          irep = irep,
#          folds = folds,
#          destin = destin,
#          mean_lambda = mean_lambdas, prob_lambdas = prob_lambdas,
#          ## The rest that is needed explicitly for flowmix()
#          ylist = ylist,
#          countslist = NULL,
#          X = X,
#          numclust = 4,
#          maxdev = 0.5)

## ----one-job-refit, eval=FALSE------------------------------------------------
#  ## Example of one replicate of model estimation (in the full data) for one pair
#  ## of regularization parameters.
#  ialpha = 1
#  ibeta = 1
#  irep = 1
#  destin = "~/Desktop"## Change to your target destination.
#  one_job_refit(ialpha = ialpha,
#                ibeta = ibeta,
#                irep = irep,
#                destin = destin,
#                mean_lambda = mean_lambdas, prob_lambdas = prob_lambdas,
#                ## The rest that is needed explicitly for flowmix()
#                ylist = ylist,
#                countslist = NULL,
#                X = X,
#                numclust = 4,
#                maxdev = 0.5,
#                )

