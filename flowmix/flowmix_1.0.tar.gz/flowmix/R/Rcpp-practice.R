## ###################
## ## Making all() ###
## ###################
## library(Rcpp)
## cppFunction('bool allC(LogicalVector x) {
##   int n = x.size();
##   int sum = 0;
##   for (int ii = 0; ii < n; ii++)
##   {
##    if(x[ii]) sum++;
##   }
##   if (sum == n)
##   {
##     return true;
##   } else {
##     return false;
##   }
## }')

## nsim = 100
## for(isim in 1:nsim){
##   boolvec = sample(c(TRUE, FALSE), 3, replace=TRUE)
##   testthat::expect_equal(allC(boolvec), all(boolvec))
## }

## set.seed(102)
## boolvec = sample(c(TRUE, FALSE), 3, replace=TRUE)
## t1 = microbenchmark::microbenchmark({
##   allC(boolvec)
## }, unit = "ns")
## t2 = microbenchmark::microbenchmark({
##   all(boolvec)
## }, unit = "ns")
## t3 = microbenchmark::microbenchmark({
##   sum(boolvec)
## }, unit = "ns")

## t1
## t2
## t3



## ########################
## ## Replacing cummin() ##
## ########################
## vec = 3:10
## t1 = microbenchmark::microbenchmark({
##   cummin(vec)
## })

##   ## NumericVector x1 = std::fill(x.begin(), x.end(), xmin);

##   ## double xmin = std::min_element(x.begin(), x.end());

## cppFunction('NumericVector cumminC(NumericVector x) {

##   NumericVector::iterator it = std::min_element(x.begin(), x.end());
##   double minval =  *it; // we want the value so dereference

##   int n = x.size();
##   NumericVector out = sugar::rep_len(minval, n);

##   return out;
## }')

##   ## NumericVector out(n);

##   ## for (int i = 0; i < n; ++i) {
##   ##   out[i] = minval;
##   ## }

## tC = microbenchmark::microbenchmark({
##   cumminC(c(5,3,8))
## }, unit = "ns")
## tR = microbenchmark::microbenchmark({
##   cummin(c(5,3,8))
## }, unit = "ns")

## cummin


## #######################
## ## Other challenges ###
## ######################$

## all()

## cumprod(), cummin(), cummax()

## diff()##. Start by assuming lag 1, and then generalise for lag n.

## range()

## var()  ## Read about the approaches you can take on wikipedia. Whenever
##        ## implementing a numerical algorithm, it’s always good to check what is
##        ## already known about the problem.
