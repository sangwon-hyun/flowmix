## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = TRUE
)
options(rmarkdown.html_vignette.check_title = FALSE)

## ----setup, message=FALSE-----------------------------------------------------
library(flowmix)
library(tidyverse)
library(RColorBrewer)

## ----generate-data, echo=TRUE-------------------------------------------------
set.seed(0)
datobj = generate_data_generic(p=5, TT=300, fac=.5, nt=2000, dimdat = 3)
ylist = datobj$ylist
X = datobj$X

## ----viz-one-cytogram, fig.width=5, fig.height=5------------------------------
plot(ylist[[1]][,1:2], ylab="", xlab="", pch=16, col=rgb(0,0,1,0.2), cex=.5)

## ----viz-covariates, fig.width=7, fig.height=5--------------------------------
matplot(X, type = 'l')

## ----fit-model----------------------------------------------------------------
numclust = 4
set.seed(0)
res = flowmix(ylist = ylist, X = X, numclust = numclust,
              mean_lambda = 0.001, prob_lambda = 0.001,
              nrep = 1)
print(res)

## ----plot-prob, fig.width=7, fig.height=5-------------------------------------
## plot_prob(res)
cols = RColorBrewer::brewer.pal(numclust, "Set2")
res$prob %>% matplot(type = 'l', lwd = 2, col = cols, xlab = "Time", ylab = "Cluster probabilities")
res$prob %>% .[1,] %>% text(x=10, y=., label=paste0("Cluster", 1:numclust))

## ---- animation.hook='ffmpeg', dev='jpeg', interval=0.2, ffmpeg.format="gif", fig.width=15, fig.height=6----
par(mfrow = c(1,3), oma = c(2,2,2,2))
ylim = c(-3,8)
xlim = c(-5,8)
for(tt in 1:res$TT){
  for(dims in list(c(1,2), c(2,3), c(3,1))){
    scatterplot_2d(ylist, res, tt, dims = dims, cex_fac=1, ylim=ylim, xlim=xlim)
  }
  mtext(outer = TRUE,
        text = paste0("t = ", tt, " out of ", res$TT),
        cex = 2)
}

## ----eval = FALSE-------------------------------------------------------------
#  maxres = get_max_lambda(destin,
#                          "maxres.Rdata",
#                          ylist = ylist,
#                          countslist = NULL,
#                          X = X,
#                          numclust = 4,
#                          maxdev = 0.5,
#                          max_mean_lambda = 40,
#                          max_prob_lambda = 2)

## ----eval=FALSE---------------------------------------------------------------
#  ## Define the locations to save the CV results.
#  destin = "."
#  
#  ## Define the CV folds (as every fifth, nfold-sized, block of indices)
#  folds = make_cv_folds(ylist, nfold = 5, verbose = FALSE, blocksize = 20)
#  
#  ## Define the candidate lambda values (logarithmically spaced)
#  cv_gridsize = 5
#  ## maxres = list(alpha = 1, beta=1)
#  prob_lambdas =  logspace(min = 0.0001, max = maxres$alpha, length = cv_gridsize)
#  mean_lambdas = logspace(min = 0.0001, max = maxres$beta, length = cv_gridsize)

## ---- eval=FALSE--------------------------------------------------------------
#  ## Example of one CV job for one pair of regularization parameters (and CV folds
#  ## and EM replicates)
#  ialpha = 1
#  ibeta = 1
#  ifold = 1
#  irep = 1
#  destin = "~/Desktop"## Change to your target destination.
#  one_job(ialpha = ialpha,
#          ibeta = ibeta,
#          ifold = ifold,
#          irep = irep,
#          folds = folds,
#          destin = destin,
#          mean_lambda = mean_lambdas, prob_lambdas = prob_lambdas,
#          ## The rest that is needed explicitly for flowmix()
#          ylist = ylist,
#          countslist = NULL,
#          X = X,
#          numclust = 4,
#          maxdev = 0.5,
#          ## verbose = TRUE
#          )

## ---- eval=FALSE--------------------------------------------------------------
#  ## Example of one replicate of model estimation (in the full data) for one pair
#  ## of regularization parameters.
#  ialpha = 1
#  ibeta = 1
#  irep = 1
#  destin = "~/Desktop"## Change to your target destination.
#  one_job_refit(ialpha = ialpha,
#                ibeta = ibeta,
#                irep = irep,
#                destin = destin,
#                mean_lambda = mean_lambdas, prob_lambdas = prob_lambdas,
#                ## The rest that is needed explicitly for flowmix()
#                ylist = ylist,
#                countslist = NULL,
#                X = X,
#                numclust = 4,
#                maxdev = 0.5,
#                )

## ----eval=FALSE---------------------------------------------------------------
#  cvres = cv.flowmix(ylist = ylist,
#                     countslist = NULL,
#                     X = X,
#                     maxdev = 0.5,
#                     numclust = 4,
#                     prob_lambdas = prob_lambdas,
#                     mean_lambdas = mean_lambdas,
#                     nrep = 10,
#                     nfold = 5,
#                     destin = "~/Desktop",
#                     mc.cores = 8)

## ----eval=FALSE---------------------------------------------------------------
#  cvres = cv_summary(destin = ".",
#                     cv_gridsize = 5,
#                     nrep = 10,
#                     nfold = 5,
#                     save = TRUE,
#                     filename = "summary.RDS")

## ----eval=FALSE---------------------------------------------------------------
#  cvres$bestres %>% print()

## -----------------------------------------------------------------------------
## Bin this data
grid = make_grid(ylist, gridsize = 30)
obj = bin_many_cytograms(ylist, grid, mc.cores = 8, verbose=FALSE)  
ylist = obj$ybin_list
countslist = obj$counts_list

## Run the algorithm on binned data
res = flowmix(ylist = ylist,
              X = X,
              countslist = countslist,
              numclust = numclust,
              mean_lambda = 0.001,
              prob_lambda = 0.001,
              verbose = FALSE,
              maxdev = 0.5)

## ----real-data----------------------------------------------------------------
## Load data
load(file = "~/repos/flowmix/demo-MGL1704.Rdata")
X = X %>% select(-time, -lat, -lon) %>% as.matrix()
ylist = ybin_list
countslist = biomass_list

## Estimate model
set.seed(1)
res = flowmix(ylist, X, numclust = 10,
              countslist = countslist,
              mean_lambda = 0.001,
              prob_lambda = 0.001,
              maxdev = 0.5,
              nrep = 1,
              verbose = FALSE)

## -----------------------------------------------------------------------------
## Default print
print(res)

## ----fig.width=10, fig.height=5-----------------------------------------------
## Plot estimated probabilities
plot_prob(res)

## ---- animation.hook='ffmpeg', dev='jpeg', interval=0.2, ffmpeg.format="gif", fig.width=15, fig.height=6----
## Three scatterplots of one time point
par(mfrow = c(1,3))
ylim = c(-3,8)
xlim = c(-5,8)
dimnames = c("diam", "red", "orange")
par(mfrow = c(1,3), oma = c(2,2,2,2))
for(tt in 1:50){
  for(dims in list(c(1,2), c(2,3), c(3,1))){
    scatterplot_2d(ylist = ylist,
                   countslist = countslist,
                   obj = res,
                   tt,
                   dims = dims, cex_fac=8,
                   pt_col = rgb(0 ,0, 1, 0.1),
                   xlab = dimnames[dims[1]],
                   ylab = dimnames[dims[2]])
  }
  mtext(outer = TRUE,
        text = paste0("t = ", tt, " out of ", res$TT),
        cex = 2)
}

