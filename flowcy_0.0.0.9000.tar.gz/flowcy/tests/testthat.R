library(testthat)
test_check("flowcy")
